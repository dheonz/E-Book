Saya sertkan bonus CSS dari teman untuk bisa anda terapkan dan pelajari lebih lanjut.

