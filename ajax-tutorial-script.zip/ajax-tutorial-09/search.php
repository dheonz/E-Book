<?php

header('Content-Type: text/xml');
echo '<response>';

$keyword = $_GET['keyword'];
$kriteria = $_GET['kriteria'];

mysql_connect("namahost","dbuser","dbpass");
mysql_select_db("dbname");

if ($kriteria == "nama") 
    $query = "SELECT * FROM mhs WHERE namamhs LIKE '%$keyword%'";
else if ($kriteria == "alamat") 
    $query = "SELECT * FROM mhs WHERE alamat LIKE '%$keyword%'";

$hasil = mysql_query($query);

while ($data = mysql_fetch_array($hasil))
{
   echo "<mhs>";
   echo "<nim>".$data['NIM']."</nim>";
   echo "<namamhs>".$data['NAMAMHS']."</namamhs>";
   echo "<alamat>".$data['ALAMAT']."</alamat>";
   echo "</mhs>";
}

echo '</response>';
?>
