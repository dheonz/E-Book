<?php

header('Content-Type: text/xml');

echo '<hasil>';
$nimmhs=$_GET['nim'];
$namamhs=$_GET['nama'];
$alamatmhs=$_GET['alamat'];

$op=$_GET['op'];

mysql_connect("namahost","dbuser","dbpass");
mysql_select_db("dbname");

if ($op == "tampildata")
{
	$query="select * from mhs";
	$hasil=mysql_query($query);
}
else if ($op=="simpandata")
{
	$query="insert into mhs values ('$nimmhs','$namamhs','$alamatmhs')";
	mysql_query($query);
	$query="select * from mhs";
	
	$hasil=mysql_query($query);
}
else if ($op == "hapusdata")
{
   $query = "DELETE FROM mhs WHERE nim = '$nimmhs'";
   mysql_query($query);
   
   $query = "SELECT * FROM mhs";
   $hasil = mysql_query($query);
}

while ($data = mysql_fetch_array($hasil))
{
   echo "<mhs>";
   echo "<nim>".$data['NIM']."</nim>";
   echo "<namamhs>".$data['NAMAMHS']."</namamhs>";
   echo "<alamat>".$data['ALAMAT']."</alamat>";
   echo "</mhs>";
}

echo '</hasil>';

?>