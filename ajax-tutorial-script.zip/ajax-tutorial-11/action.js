var xmlHttp = createXmlHttpRequestObject();

function createXmlHttpRequestObject()
{
	var xmlHttp;
	if (window.ActiveXObject)
	{
		try
		{
			xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch (e)
		{
			xmlHttp= false;
		}
	}
	else
	{
		try
		{
			xmlHttp=new XMLHttpRequest();
		}
		catch(e)
		{
			xmlHttp=false;
		}
	}

if (!xmlHttp) alert ("Object XMLHttpRequest gagal dibuat !");
else
return xmlHttp;
}

function tampil()
{
	if (xmlHttp.readyState ==4 || xmlHttp.readyState ==0 )
	{
		xmlHttp.open ("GET","datamhs.php?op=tampildata",true);
		xmlHttp.onreadystatechange = handleServerResponse;
		xmlHttp.send(null);
	}
	else
	setTimeout('tampil()',1000);
}

function simpan()
{
	
	if (xmlHttp.readyState==4 || xmlHttp.readyState==0)
	{
		nim   =encodeURIComponent(document.getElementById("nimmhs").value);
		nama  =encodeURIComponent(document.getElementById("namamhs").value);
		alamat=encodeURIComponent(document.getElementById("alamatmhs").value);
		/* kesalahan semula: kurang tanda sama dengan setelah op=simpandata&&nim */	
		xmlHttp.open("GET","datamhs.php?op=simpandata&nim="+nim+"&nama="+nama+"&alamat="+alamat,true);
		xmlHttp.onreadystatechange = handleServerResponse;
		xmlHttp.send(null);
	}
	else
	setTimeout('simpan()',1000);
}

function hapus(nim)
{
	if (xmlHttp.readyState==4 || xmlHttp.readyState==0)
	{
		xmlHttp.open("GET","datamhs.php?op=hapusdata&nim="+nim,true);
		xmlHttp.onreadystatechange = handleServerResponse;
		xmlHttp.send(null);
	}
	else
	setTimeout('hapus()',1000);
}
	
function handleServerResponse()
{
	if (xmlHttp.readyState==4)
	{
		if (xmlHttp.status == 200)
		{
			var xmlResponse = xmlHttp.responseXML;
			xmlRoot =xmlResponse.documentElement;
			
			nimArray = xmlRoot.getElementsByTagName("nim");
			namaMhsArray = xmlRoot.getElementsByTagName("namamhs");
			alamatArray = xmlRoot.getElementsByTagName("alamat");
			
			html = "<table border='1'><tr><th>NIM</th><th>Nama</th><th>Alamat</th></tr>";
			
			for (var i=0; i<nimArray.length; i++)
			{
				html += "<tr><td>" + nimArray.item(i).firstChild.data + "</td><td>" + namaMhsArray.item(i).firstChild.data + "</td><td>" + alamatArray.item(i).firstChild.data + "</td><td><a href=\"datamhs.php\" onclick=\"hapus('"+nimArray.item(i).firstChild.data+"'); return false;\">Hapus</a></td></tr>";
			}
			html = html + "</table>";
			document.getElementById("data").innerHTML = html;
		}
		else
		{
			alert("Ada kesalahan dalam mengakses server : " + xmlHttp.statusText);
		}
	}
}
	
