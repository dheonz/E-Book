<?
// koneksi ke MySQL
mysql_connect("namahost","dbUser","dbPass");
mysql_select_db("dbname");

// membuat header untuk menghasilkan dokumen XML (mime)
header('Content-Type: text/xml');

// membuat root tag pembuka
echo "<koleksi>";

// menjalankan query untuk memanggil data dalam tabel
$query = "SELECT * FROM buku";
$hasil = mysql_query($query);

// data hasil query ditampilkan ke dalam dokumen XML
while ($data = mysql_fetch_array($hasil))
{
	echo "<buku>";
	echo "<id>".$data['id']."</id>";
	echo "<judul>".$data['judul']."</judul>";
echo "<pengarang>".$data['pengarang']."</pengarang>";	
echo "<penerbit>".$data['penerbit']."</penerbit>";
echo "<tahun>".$data['tahunTerbit']."</tahun>";		
echo "</buku>";
}

// membuat root tag penutup
echo "</koleksi>";
?>
